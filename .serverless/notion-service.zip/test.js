import moment from 'moment';

console.log(moment().format('YYYY-MM-DD HH:mm:ss[+09:00]'));