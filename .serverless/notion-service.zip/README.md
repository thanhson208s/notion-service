AWS Lambda NodeJS functions for automate some Notion tasks
Skills:
    - AWS Lambda
    - Serverless framework
    - NodeJS
    - Notion API
